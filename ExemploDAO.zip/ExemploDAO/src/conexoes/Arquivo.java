package conexoes;

public class Arquivo {
	
	//faço codigo para abrir um arquivo

}
