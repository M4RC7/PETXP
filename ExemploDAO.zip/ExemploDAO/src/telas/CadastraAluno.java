package telas;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import DAO.Fabrica;
import DAO.InterfaceAluno;
import classes.Aluno;
import classes.Aluno.SEXO;

import javax.swing.JRadioButton;
import javax.swing.JComboBox;
import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CadastraAluno {

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CadastraAluno window = new CadastraAluno();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public CadastraAluno() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNome = new JLabel("Nome:");
		lblNome.setBounds(12, 51, 70, 15);
		frame.getContentPane().add(lblNome);
		
		JLabel lblCpf = new JLabel("CPF:");
		lblCpf.setBounds(12, 86, 70, 15);
		frame.getContentPane().add(lblCpf);
		
		JLabel lblMatriculado = new JLabel("Matriculado:");
		lblMatriculado.setBounds(12, 113, 89, 15);
		frame.getContentPane().add(lblMatriculado);
		
		JLabel lblSexo = new JLabel("Sexo:");
		lblSexo.setBounds(12, 140, 70, 15);
		frame.getContentPane().add(lblSexo);
		
		textField = new JTextField();
		textField.setBounds(68, 49, 114, 19);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(54, 78, 114, 19);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		JRadioButton rdbtnSim = new JRadioButton("Sim");
		rdbtnSim.setBounds(115, 105, 67, 23);
		frame.getContentPane().add(rdbtnSim);
		
		JRadioButton rdbtnNo = new JRadioButton("Não");
		rdbtnNo.setBounds(189, 105, 149, 23);
		frame.getContentPane().add(rdbtnNo);
		
		ButtonGroup matric = new ButtonGroup();
		matric.add(rdbtnNo);
		matric.add(rdbtnSim);
		
		
		JComboBox<SEXO> comboBox = new JComboBox<>();
		comboBox.setBounds(68, 135, 114, 24);
		comboBox.setModel(new DefaultComboBoxModel<>(SEXO.values()));
		frame.getContentPane().add(comboBox);
		
		JButton btnCadastrar = new JButton("Cadastrar");
		btnCadastrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					Aluno novo = new Aluno();
					
					novo.setNome(textField.getText());
					novo.setCpf(textField_1.getText());
					novo.setSexo((SEXO)comboBox.getSelectedItem());
					novo.setMatriculado(rdbtnNo.isSelected()?false:true);
					 
					InterfaceAluno x = Fabrica.criarMedDAO();
					x.cadastra(novo);
					JOptionPane.showMessageDialog(null, "Cadastrado com sucesso");
				} catch (Exception e) {
					// TODO Auto-generated catch block
					JOptionPane.showMessageDialog(null, "Algo deu errado");
				}
			}
		});
		btnCadastrar.setBounds(22, 178, 117, 25);
		frame.getContentPane().add(btnCadastrar);
		
		textField_2 = new JTextField();
		textField_2.setBounds(310, 49, 114, 19);
		frame.getContentPane().add(textField_2);
		textField_2.setColumns(10);
		
		JLabel lblBuscarPorNome = new JLabel("Buscar por nome:");
		lblBuscarPorNome.setBounds(300, 10, 124, 15);
		frame.getContentPane().add(lblBuscarPorNome);
		
		JButton btnBuscar = new JButton("Buscar");
		btnBuscar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				InterfaceAluno x = Fabrica.criarMedDAO();
				Aluno aluno = x.busca(textField_2.getText());
				textField.setText(aluno.getNome());
				textField_1.setText(aluno.getCpf());
				if(aluno.isMatriculado()){
					rdbtnSim.setSelected(true);
				}else{
					rdbtnNo.setSelected(true);
				}
				comboBox.setSelectedItem(aluno.getSexo());
			}
		});
		btnBuscar.setBounds(307, 75, 117, 25);
		frame.getContentPane().add(btnBuscar);
	}
}
