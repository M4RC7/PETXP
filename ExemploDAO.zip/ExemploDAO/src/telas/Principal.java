package telas;

import DAO.AlunoDAO;
import DAO.Fabrica;
import DAO.InterfaceAluno;
import classes.Aluno;
import classes.Aluno.SEXO;

public class Principal {
	
	public static void main(String[] args){
		
		Aluno jose = new Aluno();
		
		jose.setNome("jose");
		jose.setCpf("12343432");
		jose.setSexo(SEXO.Masculino);
		jose.setMatriculado(true);
		 
		InterfaceAluno x = Fabrica.criarMedDAO();
		x.cadastra(jose);
		
	}

}
