package DAO;



import classes.Aluno;

public interface InterfaceAluno {
	
	public void cadastra(Aluno aluno);
	public void remove(Aluno aluno);
	public Aluno busca(String nome);
	
	

}
