package DAO;

import classes.Aluno;

public class AlunoDAOArquivo implements InterfaceAluno{

	@Override
	public void cadastra(Aluno aluno) {
		// chamando Arquivo.java e abrindo o arquivo
		
	}

	@Override
	public void remove(Aluno aluno) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Aluno busca(String nome) {
		// TODO Auto-generated method stub
		return null;
	}

}
