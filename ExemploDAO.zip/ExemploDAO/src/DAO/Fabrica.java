package DAO;

public class Fabrica {

	public static InterfaceAluno criarMedDAO(){
		return new AlunoDAO();
	}
}
