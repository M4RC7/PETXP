package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import classes.Aluno;
import classes.Aluno.SEXO;
import conexoes.Mysql;

public class AlunoDAO implements InterfaceAluno{

	@Override
	public void cadastra(Aluno aluno) {
		try(Connection con = new Mysql().conecta()) {
			String sql = "insert into aluno " +
		            "(nome, cpf,matriculado,sexo)" +
		            " values (?,?,?,?)";  
			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setString(1, aluno.getNome());
			stmt.setString(2, aluno.getCpf());
			stmt.setBoolean(3, aluno.isMatriculado());
			stmt.setString(4, aluno.getSexo().toString());
			stmt.execute();
			stmt.close();
			} catch(SQLException e) {
			  System.out.println(e);
			}
		
	}

	@Override
	public void remove(Aluno aluno) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Aluno busca(String nome) {
		try(Connection con = new Mysql().conecta()) {
			String sql = "select * from aluno " +
		            "where nome = ?";  
			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setString(1, nome);
			ResultSet rs = stmt.executeQuery();
			 if (rs.next()) {
	                Aluno usuario =  new Aluno();
	                usuario.setCpf(rs.getString("cpf"));
	                usuario.setNome(rs.getString("nome"));
	                usuario.setMatriculado(rs.getBoolean("matriculado"));
	                usuario.setSexo(SEXO.valueOf(rs.getString("sexo")));
	                return usuario;
	            } else {
	                return null;
	            }
			} catch(SQLException e) {
			  System.out.println(e);
			}
		
		return null;
	}
	
	

}
